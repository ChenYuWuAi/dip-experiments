﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 DIPExperimentApplication.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MFCApplication2TYPE         130
#define IDD_DIALOG1                     310
#define IDD_BITPLANE_DLG                310
#define ID_32771                        32771
#define ID_PROCESS_INVERT               32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_GENERATE_RED                 32777
#define ID_GENERATE_BLE                 32778
#define ID_GENERATE_BLUE                32779
#define ID_GENERATE_GREEN               32780
#define ID_32781                        32781
#define ID_GENERATE_GREY                32782
#define ID_32783                        32783
#define ID_LINEAR_TRANSFORM             32784
#define ID_BITPLANE                     32785
#define IDC_STATIC_PLANE_INDEX 1001
#define IDC_BUTTON_PREV 1002
#define IDC_BUTTON_NEXT 1003
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
